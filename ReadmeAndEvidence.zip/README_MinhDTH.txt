1) here is my github: https://github.com/T16CS036/cloud-developer.git

2) my local URL look like:
http://localhost:8082/filteredimage?image_url=https://images.unsplash.com/photo-1660213372421-5df50962f52c?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=688&q=80

3) here is my project elasticbeanstalk URL:
http://project2-minhdth-dev.us-east-1.elasticbeanstalk.com/

which you can add URL for example:

http://project2-minhdth-dev.us-east-1.elasticbeanstalk.com/filteredimage?image_url=https://cdn.pixabay.com/photo/2022/07/20/07/16/woman-7333557_960_720.jpg
http://project2-minhdth-dev.us-east-1.elasticbeanstalk.com/filteredimage?image_url=https://images.unsplash.com/photo-1660096969614-afba1e29426f?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80

I've already sent the evidence pictures in the zip file!

4) but i don't know why i can't read the image on your URL below:

it keep saying to me that [Error: Could not find MIME for Buffer <null>]
(please check error.PNG)

5) sorry! because i dont have much time to do stanout(optional) work!